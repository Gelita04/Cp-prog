using Spectre.Console;

namespace MetodosFranco
{
    static class Charco
    {
        public static int ComiendoChocolates(bool[,] chocos, int[] ranas)
        {
            throw new Exception();
        }
    }
}
